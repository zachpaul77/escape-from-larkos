#!/bin/bash
eval "$venv/bin/python2 game_files/main.py"
