#About
Escape from LarkOS is a text-based puzzle game with a focus on teaching basic BASH commands. This is a project from my Intro to Unix course.


#Rules / Info

1. This game runs on any Linux distribution inside the terminal.
2. Make sure your terminal has at least 40 rows and 152 columns.
3. Execute the "start_game.sh" file to play.
4. Stay within the game directory when playing.
5. Press control + z to stop the game at any time.
6. Have fun!
